import { Job, PlacementStats } from '../types';

export const placementStats: PlacementStats = {
  totalOpenings: 34,
  totalPlaced: 142,
  highestPackage: "48.5 LPA",
  averagePackage: "11.2 LPA",
  partnerCompanies: 52
};

export const jobsData: Job[] = [
  {
    id: "1",
    title: "Associate Software Engineer",
    company: "Acme Tech Solutions",
    logoColor: "bg-gradient-to-tr from-blue-600 to-indigo-500",
    location: "Bangalore, KA",
    department: "Engineering",
    salary: "12 - 16 LPA",
    experience: "Fresher / Entry Level",
    type: "Full-time",
    postedAt: "1 day ago",
    rawDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
    description: "We are seeking a highly motivated Associate Software Engineer to join our core product team. You will participate in all phases of the software development lifecycle, from system analysis and design to testing and deployment. This is an exceptional opportunity for a talented fresher to build a robust career in full-stack engineering.",
    requirements: [
      "B.Tech/B.E./M.C.A. in Computer Science or related fields",
      "Strong foundation in data structures, algorithms, and object-oriented programming",
      "Familiarity with React, Node.js, and relational databases (SQL)",
      "Excellent communication and problem-solving skills",
      "Minimum 7.5 CGPA with no active backlogs"
    ],
    responsibilities: [
      "Write clean, scalable, and well-documented TypeScript/JavaScript code",
      "Collaborate with senior engineers to design robust backend APIs and intuitive frontends",
      "Debug and resolve production issues with minimal turnaround time",
      "Participate actively in regular code reviews and technical planning sessions",
      "Help write comprehensive unit and integration tests to ensure stability"
    ],
    benefits: [
      "Comprehensive medical insurance cover",
      "Free meals, snacks, and high-quality fitness access",
      "Self-directed learning budget of ₹50,000 per annum",
      "Annual performance-based bonuses and stock options",
      "Relocation allowance and initial housing support"
    ],
    tags: ["React", "Express", "PostgreSQL", "JavaScript"],
    deadline: "2026-06-30",
    isHot: true
  },
  {
    id: "2",
    title: "Data Analyst Intern",
    company: "Stripe Analytics Corp",
    logoColor: "bg-gradient-to-tr from-purple-600 to-indigo-500",
    location: "Remote",
    department: "Analytics",
    salary: "45k - 60k/month",
    experience: "Pre-Final / Final Year Students",
    type: "Internship",
    postedAt: "2 hours ago",
    rawDate: new Date(Date.now() - 2 * 60 * 60 * 1000),
    description: "Join our dynamic business intelligence team to transform raw data into actionable strategic insights. As a Data Analyst Intern, you will work closely with product managers and engineers to build automated pipelines, visualize user funnels, and prepare executive-level reports.",
    requirements: [
      "Pursuing a degree in Statistics, Economics, Computer Science, or Mathematics",
      "High proficiency in writing complex SQL queries",
      "Hands-on experience with Python libraries like Pandas, NumPy, and Matplotlib",
      "Knowledge of visualization tools (Tableau, PowerBI or similar)",
      "Strong analytical mind with an eye for minor discrepancies"
    ],
    responsibilities: [
      "Clean, filter, and preprocess multi-source dataset structures",
      "Build and maintain key metric dashboards for the marketing and operations teams",
      "Conduct exploratory data analysis to surface unexpected user engagement patterns",
      "Translate raw technical metrics into strategic business presentations",
      "Support standard automation of regular data pipeline reports"
    ],
    benefits: [
      "Internship completion certificate & letter of recommendation",
      "Potential for conversion to a full-time role based on performance",
      "Work-from-home infrastructure stipend (₹15,000)",
      "Weekly team-building games and dynamic social events",
      "Mentorship from senior VP of Data Analytics"
    ],
    tags: ["SQL", "Python", "Tableau", "Pandas"],
    deadline: "2026-06-25",
    isHot: true
  },
  {
    id: "3",
    title: "Backend Engineer (Node.js)",
    company: "Zest Financial Labs",
    logoColor: "bg-gradient-to-tr from-emerald-600 to-teal-500",
    location: "Mumbai, MH",
    department: "Engineering",
    salary: "14 - 18 LPA",
    experience: "Fresher to 1 Year",
    type: "Full-time",
    postedAt: "3 days ago",
    rawDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    description: "Zest is building the next-generation micro-lending API structure for emerging markets. We are searching for an entry-level Backend Engineer who is passionate about database performance, API security, and high-availability systems. You will build microservices that handle lakhs of transactions daily.",
    requirements: [
      "B.E./B.Tech in Computer Science or Information Technology",
      "Excellent understanding of Node.js, Express, and asynchronous runtime environments",
      "Understand relational and non-relational database design (MongoDB/PostgreSQL)",
      "Basic understanding of Redis caching and Docker containers",
      "Strong grasp of security principles (JWT, OAuth, CORS)"
    ],
    responsibilities: [
      "Develop secure, robust RESTful APIs to power consumer-facing apps",
      "Optimize slow database queries and design efficient data models",
      "Set up automatic unit test runners and maintain high test coverage",
      "Work together with DevOps team to orchestrate deployment plans",
      "Document API paths using OpenAPI/Swagger documentation specifications"
    ],
    benefits: [
      "Flexible work hours and work-from-home options",
      "Premium zero-deductible health and dental insurance",
      "Unlimited paid leaves and sabbatical policy",
      "Fully covered technical certifications",
      "Free daily gourmet catering service"
    ],
    tags: ["Node.js", "Express", "MongoDB", "Redis"],
    deadline: "2026-07-05"
  },
  {
    id: "4",
    title: "Product Design Trainee",
    company: "PixelCraft Studios",
    logoColor: "bg-gradient-to-tr from-rose-500 to-orange-400",
    location: "Pune, MH",
    department: "Design",
    salary: "8 - 10 LPA",
    experience: "Fresher",
    type: "Full-time",
    postedAt: "2 days ago",
    rawDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    description: "PixelCraft is an award-winning creative agency designing consumer tech apps. As a Product Design Trainee, you will learn how to transition complex wireframes into gorgeous, human-centered UI. You will study user behavior and work alongside product specialists to create mockups.",
    requirements: [
      "Degree or specialized course in Interaction Design, UI/UX, or visual arts",
      "A stunning portfolio showcasing UI templates, system layouts, or redrawn web apps",
      "Absolute mastery of Figma (autolayout, components, variants)",
      "Strong understanding of typography hierarchies, dynamic grids, and color wheels",
      "Excellent presentation skills to pitch and advocate for your designs"
    ],
    responsibilities: [
      "Create wireframes, sketches, and high-fidelity interactive user flows",
      "Assist in user testing sessions to isolate experience frictions",
      "Build and maintain a consistent visual components library",
      "Deliver fine assets and layout guidelines to our frontend engineers",
      "Collaborate with content writers to incorporate natural copy text"
    ],
    benefits: [
      "Top-tier Apple hardware setups (MacBook Pro + ultra-wide monitor)",
      "Mentorship from design industry veterans",
      "Supportive, zero-politics professional environment",
      "Paid trips to domestic UI/UX design conferences",
      "Wellness allowance of ₹5,000 per month for gym/yoga"
    ],
    tags: ["Figma", "UI/UX", "Wireframe", "Prototyping"],
    deadline: "2026-06-28"
  },
  {
    id: "5",
    title: "Frontend Engineer (React)",
    company: "Chronos Labs",
    logoColor: "bg-gradient-to-tr from-sky-500 to-cyan-400",
    location: "Bangalore, KA",
    department: "Engineering",
    salary: "11 - 15 LPA",
    experience: "Fresher to 1 Year",
    type: "Full-time",
    postedAt: "4 days ago",
    rawDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    description: "Chronos Labs is speed-optimizing enterprise supply-chain portals. We need a frontend wizard who cares intensely about virtualized lists, load times, bundle sizes, and accessible interfaces. You will build dashboards that manage massive global asset networks in real time.",
    requirements: [
      "B.Tech/B.Sc. in Technical programs with strong JavaScript basics",
      "In-depth command of React hooks, states, and client performance",
      "Knowledge of modern state management (Zustand, Redux) and Tailwind CSS",
      "Understanding of accessibility (WCAG 2.1 AA compliances)",
      "Good team coordination mindset"
    ],
    responsibilities: [
      "Convert architectural static mocks into stateful, fluid React components",
      "Ensure web apps are fully responsive and cross-browser compatible",
      "Collaborate closely with API engineers to integrate JSON endpoints",
      "Optimize images, bundle weights, and CSS rules for quick render indexes",
      "Write visual regression tests to protect the system's look"
    ],
    benefits: [
      "Top competitive compensation matching fast-growing startups",
      "Family medical coverage including parents",
      "Free transit passes or local travel reimbursement",
      "Annual leisure outbound trips",
      "Home workspace setup credit (₹20,000)"
    ],
    tags: ["React", "Tailwind", "TypeScript", "Zustand"],
    deadline: "2026-07-10"
  },
  {
    id: "6",
    title: "Graduate Engineer Trainee (GET)",
    company: "Apex Systems India",
    logoColor: "bg-gradient-to-tr from-slate-700 to-zinc-600",
    location: "Chennai, TN",
    department: "Engineering",
    salary: "6.5 - 8.5 LPA",
    experience: "Fresher",
    type: "Full-time",
    postedAt: "1 week ago",
    rawDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    description: "Apex Systems recruits promising graduate engineers for an intensive 6-month rotational training program. You will experience rotations across cloud computing, cyber security, data warehousing, and application engineering before final department assignments.",
    requirements: [
      "B.E. in CS, EC, EEE or Information Technology graduating this year",
      "Minimum 60% or 6.0 CGPA aggregates across semesters",
      "Basic programming skills in any language (Java, C++, or Python)",
      "Willingness to learn and take technical feedback positively",
      "Logical reasoning and quantitative analysis skills"
    ],
    responsibilities: [
      "Complete dedicated training modules on cloud, database, and dev practices",
      "Develop minor functional mock software modules for internal audits",
      "Assist primary development teams in bug hunting and log reviews",
      "Present project metrics to steering committees at the end of each rotation",
      "Abide by enterprise data security and compliance directives"
    ],
    benefits: [
      "Rigorous industry-accredited certifications at zero cost",
      "Guaranteed standard progression path with bi-annual appraisals",
      "Subsidized company accommodation for the first 30 days",
      "Comprehensive basic health safety insurance planning",
      "Subsidized corporate shuttle network coverage"
    ],
    tags: ["Java", "SQL", "Cloud Concepts", "C++"],
    deadline: "2026-06-22"
  },
  {
    id: "7",
    title: "Technical Writer Intern",
    company: "ScribeDoc Platform",
    logoColor: "bg-gradient-to-tr from-yellow-500 to-amber-500",
    location: "Noida, UP",
    department: "Product Support",
    salary: "30k - 38k/month",
    experience: "Fresher / Students",
    type: "Internship",
    postedAt: "5 days ago",
    rawDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    description: "Love explaining complex tools simply? ScribeDoc creates developer documentation platforms. As a Technical Writer Intern, you will review software specs, chat with API architects, and write clear API tutorials that developers globally will depend upon.",
    requirements: [
      "Enrolled in engineering, creative writing, english, or related branches",
      "Ability to understand basic code blocks (HTML, REST paths, curl calls)",
      "Impeccable English spelling, grammar, and narrative clarity",
      "Familiarity with Markdown format is highly preferred",
      "Detail-oriented with a drive to create readable documentation"
    ],
    responsibilities: [
      "Author integration guides, code snippets explanations, and helper charts",
      "Review user guides for readability, broken links, or stale command codes",
      "Collaborate on video outline scripts for system setup guides",
      "Gather active feedback from developer forums to restructure guides",
      "Contribute to UI microcopy and tooltip text"
    ],
    benefits: [
      "Flexible schedule to accommodate university exams",
      "Stipend matching premium product intern packages",
      "Inclusion in regular company offsites and skill seminars",
      "Letter of Certificate and direct Full-time conversion prospects",
      "Kindle Paperwhite unlimited subscription during tenure"
    ],
    tags: ["Markdown", "Technical Writing", "API Guides", "Documentation"],
    deadline: "2026-06-24"
  },
  {
    id: "8",
    title: "AI Researches Trainee",
    company: "DeepMind Wave",
    logoColor: "bg-gradient-to-tr from-violet-600 to-fuchsia-500",
    location: "Hyderabad, TS",
    department: "Research",
    salary: "18 - 22 LPA",
    experience: "Fresher / Post-Graduate Preferred",
    type: "Full-time",
    postedAt: "12 hours ago",
    rawDate: new Date(Date.now() - 12 * 60 * 60 * 1000),
    description: "DeepMind Wave is designing multimodal agents for industrial inventory automation. We are seeking an aspiring, bright AI Research Trainee who is excited about training pipelines, retrieval latency optimizations, and evaluation benchmark curation.",
    requirements: [
      "M.Tech / M.E / MS / High-CGPA B.Tech in CS/DS/AI specialties",
      "Expert knowledge of deep learning frameworks (PyTorch or JAX)",
      "Hands-on experience with vector stores, semantic queries, and fine-tuning",
      "Strong coding skills in Python, Git, and Docker",
      "Prior scholarly project logs or publications is a massive benefit"
    ],
    responsibilities: [
      "Implement and test cutting-edge research algorithms from published papers",
      "Build automated datasets benchmark evaluation pipelines",
      "Optimize transformer models for local embedded runtime environments",
      "Collaborate on writing tech whitepapers and system specs",
      "Clean, filter, and balance synthetic multi-modal datasets"
    ],
    benefits: [
      "Work with high-end, dedicated Cloud GPU high-performance arrays",
      "Co-authorship credits on patents and top-tier conference submittals",
      "Top-bracket pay scale with lucrative equity component structures",
      "Fully paid attendance to top international AI conferences (NeurIPS, CVPR)",
      "Premium wellness, healthcare, and meal plans"
    ],
    tags: ["PyTorch", "Transformers", "LLMs", "Python"],
    deadline: "2026-07-15",
    isHot: true
  }
];
