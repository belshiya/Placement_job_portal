export interface Job {
  id: string;
  title: string;
  company: string;
  logoColor: string; // Tailwind background color class, e.g., 'bg-indigo-600'
  location: string;
  department: string;
  salary: string;
  experience: string;
  type: 'Full-time' | 'Internship' | 'Part-time' | 'Contract';
  postedAt: string; // e.g. "2026-06-15" (or relative string)
  rawDate: Date; // For sorting
  description: string;
  requirements: string[];
  responsibilities: string[];
  benefits: string[];
  tags: string[];
  deadline: string;
  isHot?: boolean;
}

export interface Application {
  id: string;
  jobId: string;
  studentName: string;
  studentEmail: string;
  rollNumber: string;
  resumeName: string;
  coverLetter?: string;
  appliedAt: string;
  status: 'Applied' | 'Reviewing' | 'Shortlisted' | 'Offered' | 'Declined';
}

export interface PlacementStats {
  totalOpenings: number;
  totalPlaced: number;
  highestPackage: string;
  averagePackage: string;
  partnerCompanies: number;
}
