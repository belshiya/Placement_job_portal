import React, { useState, useRef } from 'react';
import { Upload, X, CheckCircle, HelpCircle, FileText, Activity } from 'lucide-react';
import { Job, Application } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ApplicationFormProps {
  job: Job;
  onClose: () => void;
  onSubmit: (application: Omit<Application, 'id' | 'appliedAt' | 'status'>) => void;
}

export default function ApplicationForm({ job, onClose, onSubmit }: ApplicationFormProps) {
  const [formData, setFormData] = useState({
    studentName: '',
    studentEmail: '',
    rollNumber: '',
    cgpa: '',
    coverLetter: '',
  });

  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [resumeError, setResumeError] = useState<string>('');
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  // Drag & drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    setResumeError('');

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      validateAndSetFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setResumeError('');
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      validateAndSetFile(file);
    }
  };

  const validateAndSetFile = (file: File) => {
    const allowedExtensions = ['pdf', 'doc', 'docx'];
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    
    if (!fileExtension || !allowedExtensions.includes(fileExtension)) {
      setResumeError('Invalid file type. Only PDF, DOC, or DOCX are accepted.');
      setResumeFile(null);
      return;
    }

    // 5MB Max Size limit
    if (file.size > 5 * 1024 * 1024) {
      setResumeError('File is too large. Maximum size allowed is 5MB.');
      setResumeFile(null);
      return;
    }

    setResumeFile(file);
    setResumeError('');
  };

  const selectFileManually = () => {
    fileInputRef.current?.click();
  };

  const clearSelectedFile = () => {
    setResumeFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.studentName.trim()) errors.studentName = 'Full Name is required';
    
    if (!formData.studentEmail.trim()) {
      errors.studentEmail = 'Email key is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.studentEmail)) {
      errors.studentEmail = 'Invalid email syntax';
    }

    if (!formData.rollNumber.trim()) {
      errors.rollNumber = 'College Roll Number is required';
    }

    if (!formData.cgpa.trim()) {
      errors.cgpa = 'CGPA is required';
    } else {
      const gpa = parseFloat(formData.cgpa);
      if (isNaN(gpa) || gpa < 0 || gpa > 10) {
        errors.cgpa = 'CGPA must be a decimal value between 0 and 10';
      }
    }

    if (!resumeFile) {
      setResumeError('Please upload/select your resume to proceed');
      return false;
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    onSubmit({
      jobId: job.id,
      studentName: formData.studentName,
      studentEmail: formData.studentEmail,
      rollNumber: formData.rollNumber,
      resumeName: resumeFile ? resumeFile.name : 'resume_academic.pdf',
      coverLetter: formData.coverLetter,
    });
  };

  return (
    <div id="application-form-overlay" className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <motion.div
        id="application-form-modal"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-100">
          <div>
            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100 tracking-wider uppercase">
              Application Intake
            </span>
            <h2 className="text-sm font-bold text-slate-800 mt-1 line-clamp-1">
              Apply for {job.title}
            </h2>
            <p className="text-[11px] text-slate-400 font-medium">{job.company} • {job.location}</p>
          </div>
          <button
            id="close-application-form-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content scrolling */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Student Name */}
            <div id="field-st-name">
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                id="inp-student-name"
                type="text"
                name="studentName"
                value={formData.studentName}
                onChange={handleInputChange}
                placeholder="John Doe"
                className={`w-full text-xs rounded-lg border px-3 py-2.5 outline-hidden focus:ring-1 transition-all ${
                  formErrors.studentName
                    ? 'border-rose-400 bg-rose-50/20 focus:ring-rose-400 focus:border-rose-400'
                    : 'border-slate-200 bg-slate-50/50 focus:border-blue-500 focus:bg-white focus:ring-blue-500'
                }`}
              />
              {formErrors.studentName && (
                <p className="text-[10px] text-rose-500 mt-1">{formErrors.studentName}</p>
              )}
            </div>

            {/* Student Email */}
            <div id="field-st-email">
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                University Email <span className="text-rose-500">*</span>
              </label>
              <input
                id="inp-student-email"
                type="email"
                name="studentEmail"
                value={formData.studentEmail}
                onChange={handleInputChange}
                placeholder="johndoe@university.edu"
                className={`w-full text-xs rounded-lg border px-3 py-2.5 outline-hidden focus:ring-1 transition-all ${
                  formErrors.studentEmail
                    ? 'border-rose-400 bg-rose-50/20 focus:ring-rose-400 focus:border-rose-400'
                    : 'border-slate-200 bg-slate-50/50 focus:border-blue-500 focus:bg-white focus:ring-blue-500'
                }`}
              />
              {formErrors.studentEmail && (
                <p className="text-[10px] text-rose-500 mt-1">{formErrors.studentEmail}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Roll Number */}
            <div id="field-st-roll">
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                Roll Number / Student ID <span className="text-rose-500">*</span>
              </label>
              <input
                id="inp-student-roll"
                type="text"
                name="rollNumber"
                value={formData.rollNumber}
                onChange={handleInputChange}
                placeholder="CS26-045"
                className={`w-full text-xs rounded-lg border px-3 py-2.5 outline-hidden focus:ring-1 transition-all ${
                  formErrors.rollNumber
                    ? 'border-rose-400 bg-rose-50/20 focus:ring-rose-400 focus:border-rose-400'
                    : 'border-slate-200 bg-slate-50/50 focus:border-blue-500 focus:bg-white focus:ring-blue-500'
                }`}
              />
              {formErrors.rollNumber && (
                <p className="text-[10px] text-rose-500 mt-1">{formErrors.rollNumber}</p>
              )}
            </div>

            {/* CGPA */}
            <div id="field-st-cgpa">
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                Current CGPA (Out of 10) <span className="text-rose-500">*</span>
              </label>
              <input
                id="inp-student-cgpa"
                type="text"
                name="cgpa"
                value={formData.cgpa}
                onChange={handleInputChange}
                placeholder="8.45"
                className={`w-full text-xs rounded-lg border px-3 py-2.5 outline-hidden focus:ring-1 transition-all ${
                  formErrors.cgpa
                    ? 'border-rose-400 bg-rose-50/20 focus:ring-rose-400 focus:border-rose-400'
                    : 'border-slate-200 bg-slate-50/50 focus:border-blue-500 focus:bg-white focus:ring-blue-500'
                }`}
              />
              {formErrors.cgpa && (
                <p className="text-[10px] text-rose-500 mt-1">{formErrors.cgpa}</p>
              )}
            </div>
          </div>

          {/* Drag and Drop Resume Section */}
          <div id="field-st-resume">
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Resume Upload (PDF, DOCX) <span className="text-rose-500">*</span>
            </label>
            
            <div
              id="drag-and-drop-container"
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-5 flex flex-col items-center justify-center transition-all cursor-pointer ${
                dragActive
                  ? 'border-blue-500 bg-blue-50/30'
                  : resumeFile
                  ? 'border-emerald-300 bg-emerald-50/10'
                  : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300'
              }`}
              onClick={selectFileManually}
            >
              <input
                ref={fileInputRef}
                id="resume-file-input"
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleFileChange}
                className="hidden"
              />

              {!resumeFile ? (
                <>
                  <Upload className={`w-8 h-8 mb-2 transition-transform ${dragActive ? 'text-blue-500 scale-110' : 'text-slate-400'}`} />
                  <p className="text-xs font-semibold text-slate-700">
                    Drag and drop resume here, or <span className="text-blue-600 underline">browse</span>
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1">Accepts PDF, DOC, DOCX files up to 5MB</p>
                </>
              ) : (
                <div className="flex items-center justify-between w-full bg-emerald-50 border border-emerald-100 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-emerald-600" />
                    <div>
                      <p className="text-xs font-semibold text-slate-800 line-clamp-1">{resumeFile.name}</p>
                      <p className="text-[10px] text-slate-500">{(resumeFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                    </div>
                  </div>
                  <button
                    id="clear-resume-btn"
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      clearSelectedFile();
                    }}
                    className="p-1 rounded-md text-emerald-600 hover:bg-emerald-100 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
            {resumeError && (
              <p id="resume-err" className="text-[10px] text-rose-500 mt-1">{resumeError}</p>
            )}
          </div>

          {/* Cover Letter */}
          <div id="field-st-letter">
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Add a brief pitch / cover letter <span className="text-slate-400">(Optional)</span>
            </label>
            <textarea
              id="inp-student-letter"
              name="coverLetter"
              value={formData.coverLetter}
              onChange={handleInputChange}
              rows={3}
              placeholder="Explain why you are an ideal fit for this role..."
              className="w-full text-xs rounded-lg border border-slate-200 bg-slate-50/50 px-3 py-2 outline-hidden focus:border-blue-500 focus:bg-white focus:ring-1 focus:ring-blue-500 transition-all font-medium leading-relaxed"
            />
          </div>
        </form>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3.5">
          <button
            id="cancel-application-btn"
            type="button"
            onClick={onClose}
            className="text-xs font-bold text-slate-500 hover:text-slate-800 py-2.5 px-4 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            id="submit-application-btn"
            type="button"
            onClick={handleSubmit}
            className="text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 py-2.5 px-5 rounded-lg transition-colors shadow-xs hover:shadow-md cursor-pointer"
          >
            Submit Application
          </button>
        </div>
      </motion.div>
    </div>
  );
}
