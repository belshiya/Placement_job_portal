import React from 'react';
import { Job, Application } from '../types';
import { MapPin, Calendar, Clock, DollarSign, Award, CheckCircle2, Bookmark, BookmarkCheck, FileText, Check, ShieldAlert } from 'lucide-react';
import { motion } from 'motion/react';

interface JobDetailViewProps {
  job: Job | undefined;
  isBookmarked: boolean;
  onBookmarkToggle: () => void;
  isApplied: boolean;
  appliedInfo?: Application;
  onApplyClick: () => void;
}

export default function JobDetailView({
  job,
  isBookmarked,
  onBookmarkToggle,
  isApplied,
  appliedInfo,
  onApplyClick,
}: JobDetailViewProps) {
  if (!job) {
    return (
      <div id="no-job-selected-container" className="h-full flex flex-col items-center justify-center text-center p-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
        <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-3">
          <Clock className="w-6 h-6" />
        </div>
        <h3 className="text-sm font-bold text-slate-700">No Job Selected</h3>
        <p className="text-xs text-slate-400 max-w-xs mt-1">
          Select a job opening from the lists on the left to review its eligibility guidelines and benefits.
        </p>
      </div>
    );
  }

  const initials = job.company
    .split(' ')
    .map(word => word[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const getStatusBgColor = (status: string) => {
    switch (status) {
      case 'Applied': return 'bg-blue-600';
      case 'Reviewing': return 'bg-amber-500';
      case 'Shortlisted': return 'bg-emerald-600';
      case 'Offered': return 'bg-purple-600';
      default: return 'bg-slate-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'Applied': return 'Initial CV Received';
      case 'Reviewing': return 'Under Coordinator Review';
      case 'Shortlisted': return 'Shortlisted for Interviews!';
      case 'Offered': return 'Offered - Check placement email inbox!';
      default: return 'Under Process';
    }
  };

  return (
    <div id={`job-detail-panel-${job.id}`} className="bg-white rounded-xl border border-slate-100 shadow-xs flex flex-col h-full overflow-hidden">
      {/* Top Banner Cover Accent */}
      <div className={`h-24 w-full bg-linear-to-r from-slate-100 to-slate-200/50 relative overflow-hidden flex items-end p-4 border-b border-slate-100`}>
        <div className="absolute right-4 top-4">
          <button
            id={`detail-bookmark-btn-${job.id}`}
            onClick={onBookmarkToggle}
            className={`p-2 rounded-lg border transition-colors ${
              isBookmarked
                ? 'bg-blue-50 border-blue-200 text-blue-600'
                : 'bg-white border-slate-200 text-slate-500 hover:text-slate-700 hover:bg-slate-50'
            }`}
            title={isBookmarked ? "Remove Bookmark" : "Bookmark Job"}
          >
            {isBookmarked ? (
              <BookmarkCheck className="w-5 h-5 fill-blue-600" />
            ) : (
              <Bookmark className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto p-5 md:p-6 space-y-6">
        {/* Header Profile Info */}
        <div className="flex items-start gap-4 -mt-12 relative z-10">
          <div className={`w-16 h-16 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-md border-2 border-white ${job.logoColor}`}>
            {initials}
          </div>
          <div>
            <h2 id="job-detail-title" className="text-base md:text-lg font-extrabold text-slate-800 tracking-tight leading-snug">{job.title}</h2>
            <div className="flex items-center gap-1.5 flex-wrap text-xs text-slate-500 font-medium mt-0.5">
              <span className="font-semibold text-slate-700">{job.company}</span>
              <span>•</span>
              <span>{job.location}</span>
              <span>•</span>
              <span className="text-slate-400">{job.department}</span>
            </div>
          </div>
        </div>

        {/* Fact Sheet Highlight Grid */}
        <div id="job-detail-factsheet" className="grid grid-cols-2 lg:grid-cols-4 gap-3 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
          <div className="flex gap-2">
            <div className="p-1.5 bg-blue-50 text-blue-600 rounded-lg h-9 w-9 flex items-center justify-center border border-blue-100">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Salary Package</p>
              <p className="text-xs font-bold text-slate-800">{job.salary}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <div className="p-1.5 bg-purple-50 text-purple-600 rounded-lg h-9 w-9 flex items-center justify-center border border-purple-100">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Experience</p>
              <p className="text-xs font-bold text-slate-800">{job.experience}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg h-9 w-9 flex items-center justify-center border border-amber-100">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Apply Before</p>
              <p className="text-xs font-bold text-slate-800">{job.deadline}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg h-9 w-9 flex items-center justify-center border border-emerald-100">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Posted On</p>
              <p className="text-xs font-bold text-slate-800">{job.postedAt}</p>
            </div>
          </div>
        </div>

        {/* About Job Description */}
        <div>
          <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider mb-2">Job Overview</h3>
          <p className="text-xs text-slate-600 leading-relaxed font-normal">{job.description}</p>
        </div>

        {/* Requirements */}
        <div>
          <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider mb-2.5">Academic & Technical Eligibility</h3>
          <ul className="space-y-2">
            {job.requirements.map((req, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-600 leading-relaxed">
                <Check className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                <span>{req}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Responsibilities */}
        <div>
          <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider mb-2.5">Key Responsibilities</h3>
          <ul className="space-y-2">
            {job.responsibilities.map((resp, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-600 leading-relaxed">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0"></div>
                <span>{resp}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Benefits */}
        <div>
          <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider mb-2.5">Employee Compensation & Benefits</h3>
          <ul className="space-y-2">
            {job.benefits.map((benefit, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-600 leading-relaxed">
                <span className="text-amber-500 font-extrabold shrink-0">✦</span>
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Persistent Sticky Call to Action Footer */}
      <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
        <div className="hidden sm:block text-left">
          <p className="text-[10px] text-slate-400 uppercase font-bold">Recruiter Stream</p>
          <p className="text-xs font-bold text-slate-700">{job.company} HR Cell</p>
        </div>

        {isApplied && appliedInfo ? (
          <div id="applied-status-panel" className="w-full sm:w-auto bg-white border border-slate-200 rounded-xl p-3 shadow-xs">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <p className="text-[11px] font-bold text-emerald-700 uppercase tracking-wide">Application Active</p>
                <p className="text-[10px] text-slate-400">Submitted at {appliedInfo.appliedAt}</p>
              </div>
            </div>
            
            {/* Minimal tracker status bar */}
            <div className="flex items-center gap-1.5 mt-2 bg-slate-50 rounded-lg p-2 border border-slate-100">
              <div className={`w-2 h-2 rounded-full ${getStatusBgColor(appliedInfo.status)} animate-pulse`}></div>
              <div className="text-[10px]">
                <span className="font-semibold text-slate-500">Status: </span>
                <span className="font-bold text-slate-700">{getStatusText(appliedInfo.status)}</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-slate-400 pl-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span className="line-clamp-1">Resume: <strong>{appliedInfo.resumeName}</strong></span>
            </div>
          </div>
        ) : (
          <button
            id="apply-job-action-btn"
            onClick={onApplyClick}
            className="w-full sm:w-auto text-xs font-extrabold text-white bg-blue-600 hover:bg-blue-700 py-3 px-8 rounded-lg transition-colors shadow-xs hover:shadow-md cursor-pointer flex items-center justify-center gap-2"
          >
            Apply for this Position
          </button>
        )}
      </div>
    </div>
  );
}
