import React from 'react';
import { Filter, X, MapPin, Briefcase, ChevronDown, Award } from 'lucide-react';
import { FilterState } from '../App'; // We will define this in App.tsx

interface FiltersSidebarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  availableLocations: string[];
  availableDepartments: string[];
  availableTypes: string[];
  onClear: () => void;
  resultsCount: number;
}

export default function FiltersSidebar({
  filters,
  setFilters,
  availableLocations,
  availableDepartments,
  availableTypes,
  onClear,
  resultsCount,
}: FiltersSidebarProps) {
  const handleLocationChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters(prev => ({ ...prev, location: e.target.value }));
  };

  const handleDepartmentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters(prev => ({ ...prev, department: e.target.value }));
  };

  const handleTypeChange = (typeVal: string) => {
    setFilters(prev => ({
      ...prev,
      type: prev.type === typeVal ? '' : typeVal, // Toggle behavior
    }));
  };

  const handleExperienceChange = (expVal: string) => {
    setFilters(prev => ({
      ...prev,
      experience: prev.experience === expVal ? '' : expVal,
    }));
  };

  const experienceLevels = [
    { label: "Fresher Only", value: "fresher" },
    { label: "0 - 1 Year", value: "entry" },
    { label: "Post Graduate / Special", value: "postgrade" }
  ];

  const activeFiltersCount = 
    (filters.location ? 1 : 0) + 
    (filters.department ? 1 : 0) + 
    (filters.type ? 1 : 0) + 
    (filters.experience ? 1 : 0);

  return (
    <div id="filter-sidebar-card" className="bg-white rounded-xl border border-slate-100 p-5 shadow-xs sticky top-24">
      <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-500" />
          <h2 className="text-sm font-semibold text-slate-800">Filter Openings</h2>
          {activeFiltersCount > 0 && (
            <span id="active-filters-badge" className="text-[10px] font-bold bg-blue-50 text-blue-600 rounded-full px-2 py-0.5 border border-blue-100">
              {activeFiltersCount}
            </span>
          )}
        </div>
        {activeFiltersCount > 0 && (
          <button
            id="clear-filters-btn"
            onClick={onClear}
            className="text-[11px] font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 transition-colors"
          >
            Clear All
          </button>
        )}
      </div>

      {/* Location Filter */}
      <div className="mb-5" id="filter-group-location">
        <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-slate-400" />
          Preferred Location
        </label>
        <div className="relative">
          <select
            id="location-filter-select"
            value={filters.location}
            onChange={handleLocationChange}
            className="w-full bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg px-3 py-2.5 outline-hidden appearance-none cursor-pointer focus:border-blue-500 focus:bg-white transition-all font-medium"
          >
            <option value="">All Locations (India & Remote)</option>
            {availableLocations.map(loc => (
              <option key={loc} value={loc}>
                {loc}
              </option>
            ))}
          </select>
          <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
        </div>
      </div>

      {/* Department Filter */}
      <div className="mb-5" id="filter-group-department">
        <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Briefcase className="w-3.5 h-3.5 text-slate-400" />
          Department / Stream
        </label>
        <div className="relative">
          <select
            id="department-filter-select"
            value={filters.department}
            onChange={handleDepartmentChange}
            className="w-full bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg px-3 py-2.5 outline-hidden appearance-none cursor-pointer focus:border-blue-500 focus:bg-white transition-all font-medium"
          >
            <option value="">All Streams</option>
            {availableDepartments.map(dept => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>
          <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
        </div>
      </div>

      {/* Employment Type Filter (Checkboxes) */}
      <div className="mb-5" id="filter-group-type">
        <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
          Employment Type
        </label>
        <div className="space-y-2 mt-2">
          {availableTypes.map(type => {
            const isChecked = filters.type === type;
            return (
              <button
                key={type}
                id={`chk-type-${type.toLowerCase().replace(' ', '-')}`}
                onClick={() => handleTypeChange(type)}
                className={`flex items-center justify-between w-full text-left px-3 py-2 rounded-lg border text-xs font-medium transition-all ${
                  isChecked
                    ? 'bg-blue-50 border-blue-200 text-blue-700 font-semibold'
                    : 'bg-white border-slate-100 text-slate-600 hover:bg-slate-50 hover:border-slate-200'
                }`}
              >
                <span>{type}</span>
                {isChecked && (
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Experience Level Filter (Pills) */}
      <div className="mb-4" id="filter-group-experience">
        <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Award className="w-3.5 h-3.5 text-slate-400" />
          Experience Profile
        </label>
        <div className="grid grid-cols-2 gap-2 mt-2" id="experience-toggle-chips">
          {experienceLevels.map(level => {
            const isSelected = filters.experience === level.value;
            return (
              <button
                key={level.value}
                id={`chip-exp-${level.value}`}
                onClick={() => handleExperienceChange(level.value)}
                className={`text-[10px] font-medium py-2 px-2.5 rounded-lg border text-center transition-all ${
                  isSelected
                    ? 'bg-slate-800 border-slate-800 text-white font-semibold shadow-xs'
                    : 'bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100 hover:border-slate-200'
                }`}
              >
                {level.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
        <span>Displaying:</span>
        <span id="results-count-sidebar" className="font-semibold text-slate-700">{resultsCount} openings</span>
      </div>
    </div>
  );
}
