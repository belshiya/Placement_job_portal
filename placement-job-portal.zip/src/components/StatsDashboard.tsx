import React from 'react';
import { Briefcase, TrendingUp, Users, Award, Building2 } from 'lucide-react';
import { placementStats } from '../data/jobsData';
import { motion } from 'motion/react';

export default function StatsDashboard() {
  const stats = [
    {
      id: "stat-openings",
      label: "Active Openings",
      value: placementStats.totalOpenings,
      icon: Briefcase,
      color: "text-blue-600 bg-blue-50 border-blue-100",
      description: "Roles hiring now"
    },
    {
      id: "stat-placed",
      label: "Total Students Placed",
      value: placementStats.totalPlaced,
      icon: Users,
      color: "text-emerald-600 bg-emerald-50 border-emerald-100",
      description: "Current academic year"
    },
    {
      id: "stat-average",
      label: "Average Package",
      value: placementStats.averagePackage,
      icon: TrendingUp,
      color: "text-purple-600 bg-purple-50 border-purple-100",
      description: "Highest ever mean index"
    },
    {
      id: "stat-highest",
      label: "Highest Package",
      value: placementStats.highestPackage,
      icon: Award,
      color: "text-rose-600 bg-rose-50 border-rose-100",
      description: "International offer"
    },
    {
      id: "stat-partners",
      label: "Recruiting Partners",
      value: `${placementStats.partnerCompanies}+`,
      icon: Building2,
      color: "text-amber-600 bg-amber-50 border-amber-100",
      description: "Top-tier MNCs & startups"
    }
  ];

  return (
    <div id="placement-stats-section" className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4 mb-6">
      {stats.map((stat, i) => {
        const IconComponent = stat.icon;
        return (
          <motion.div
            key={stat.id}
            id={stat.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            className="flex flex-col justify-between p-3 md:p-4 bg-white rounded-xl border border-slate-100 shadow-xs hover:shadow-md transition-all duration-200"
          >
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{stat.label}</span>
              <div className={`p-1.5 md:p-2 rounded-lg border ${stat.color}`}>
                <IconComponent className="w-4 h-4" />
              </div>
            </div>
            <div>
              <p className="text-lg md:text-2xl font-bold text-slate-800 tracking-tight">{stat.value}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{stat.description}</p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
