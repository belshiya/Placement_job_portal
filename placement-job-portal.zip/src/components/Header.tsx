import React from 'react';
import { GraduationCap, Bookmark, Briefcase, FileCheck2, UserCircle2, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface HeaderProps {
  currentTab: 'explore' | 'bookmarks' | 'applied';
  onTabChange: (tab: 'explore' | 'bookmarks' | 'applied') => void;
  bookmarksCount: number;
  appliedCount: number;
}

export default function Header({
  currentTab,
  onTabChange,
  bookmarksCount,
  appliedCount,
}: HeaderProps) {
  return (
    <header id="app-header-navigation" className="bg-white border-b border-slate-100 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-3 md:py-4 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Placement Brand Logo Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-100">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-extrabold text-slate-800 tracking-tight flex items-center gap-1.5">
              Placement Cell Board
              <span className="text-[10px] font-bold bg-blue-50 text-blue-600 rounded-md px-1.5 py-0.5 border border-blue-100 uppercase tracking-widest leading-none">
                CAMPUS
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 font-medium">Explore & apply to elite campus placement drives</p>
          </div>
        </div>

        {/* Tab Selection Filter Controls */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl w-full md:w-auto" id="nav-tabs-deck">
          <button
            id="tab-explore-btn"
            onClick={() => onTabChange('explore')}
            className={`flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              currentTab === 'explore'
                ? 'bg-white text-blue-600 shadow-xs border border-transparent'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            Explore Openings
          </button>

          <button
            id="tab-bookmarks-btn"
            onClick={() => onTabChange('bookmarks')}
            className={`flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all relative ${
              currentTab === 'bookmarks'
                ? 'bg-white text-blue-600 shadow-xs border border-transparent'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            Saved Jobs
            {bookmarksCount > 0 && (
              <span id="badge-bookmarks" className="absolute -top-1 -right-1 flex h-4 min-w-[16px] px-1 items-center justify-center rounded-full bg-blue-600 text-[9px] font-bold text-white border-2 border-white">
                {bookmarksCount}
              </span>
            )}
          </button>

          <button
            id="tab-applied-btn"
            onClick={() => onTabChange('applied')}
            className={`flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all relative ${
              currentTab === 'applied'
                ? 'bg-white text-blue-600 shadow-xs border border-transparent'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            My Applications
            {appliedCount > 0 && (
              <span id="badge-applied" className="absolute -top-1 -right-1 flex h-4 min-w-[16px] px-1 items-center justify-center rounded-full bg-emerald-600 text-[9px] font-bold text-white border-2 border-white">
                {appliedCount}
              </span>
            )}
          </button>
        </div>

        {/* Student Profile Overview Card */}
        <div id="student-identity-pill" className="hidden lg:flex items-center gap-2.5 bg-slate-50 border border-slate-100 rounded-xl px-4 py-2.5 max-w-sm">
          <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">
            <UserCircle2 className="w-5 h-5" />
          </div>
          <div className="text-left font-sans">
            <h4 className="text-xs font-bold text-slate-700">Student Profile</h4>
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium">
              <span>Roll: CS26-045</span>
              <span>•</span>
              <span className="text-emerald-600 font-bold">8.45 CGPA</span>
            </div>
          </div>
        </div>

      </div>
    </header>
  );
}
