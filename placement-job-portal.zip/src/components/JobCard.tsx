import React from 'react';
import { Job, Application } from '../types';
import { MapPin, Calendar, Flame, Bookmark, BookmarkCheck, Briefcase, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface JobCardProps {
  key?: string;
  job: Job;
  isSelected: boolean;
  onSelect: () => void;
  isBookmarked: boolean;
  onBookmarkToggle: (e: React.MouseEvent) => void;
  appliedInfo?: Application;
}

export default function JobCard({
  job,
  isSelected,
  onSelect,
  isBookmarked,
  onBookmarkToggle,
  appliedInfo,
}: JobCardProps) {
  // Generate logo initials
  const initials = job.company
    .split(' ')
    .map(word => word[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Applied': return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'Reviewing': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'Shortlisted': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      case 'Offered': return 'bg-purple-50 text-purple-700 border-purple-100';
      case 'Declined': return 'bg-rose-50 text-rose-700 border-rose-100';
      default: return 'bg-slate-50 text-slate-700 border-slate-100';
    }
  };

  return (
    <motion.div
      id={`job-card-${job.id}`}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.15 }}
      onClick={onSelect}
      className={`relative flex flex-col p-4 mb-3.5 rounded-xl border transition-all cursor-pointer select-none ${
        isSelected
          ? 'bg-blue-50/40 border-blue-600 shadow-xs'
          : 'bg-white border-slate-100 hover:border-slate-300 shadow-xs hover:shadow-md'
      }`}
    >
      {/* Hot badge and Bookmark controls */}
      <div className="flex items-start justify-between gap-3 mb-2.5">
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-xs ${job.logoColor}`}>
            {initials}
          </div>
          <div>
            <h4 className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">{job.company}</h4>
            <h3 className="text-xs font-bold text-slate-800 line-clamp-1">{job.title}</h3>
          </div>
        </div>

        <div className="flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
          {job.isHot && (
            <span id={`hot-badge-${job.id}`} className="flex items-center gap-0.5 text-[9px] font-bold text-orange-600 bg-orange-50 border border-orange-100 px-1.5 py-0.5 rounded-md">
              <Flame className="w-3 h-3 fill-orange-500 text-orange-500" />
              HOT
            </span>
          )}
          <button
            id={`bookmark-btn-${job.id}`}
            onClick={onBookmarkToggle}
            className={`p-1.5 rounded-lg border transition-colors ${
              isBookmarked
                ? 'bg-blue-50 border-blue-200 text-blue-600'
                : 'bg-slate-50 border-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-100'
            }`}
            title={isBookmarked ? "Remove Bookmark" : "Bookmark Job"}
          >
            {isBookmarked ? (
              <BookmarkCheck className="w-4 h-4 fill-blue-600" />
            ) : (
              <Bookmark className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Tags and badges */}
      <div className="flex items-center gap-1.5 flex-wrap text-[10px] text-slate-500 mb-3">
        <span className="flex items-center gap-1 font-semibold text-slate-700 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
          <Briefcase className="w-3 h-3 text-slate-400" />
          {job.type}
        </span>
        <span className="bg-slate-50 border border-slate-100 text-slate-600 px-2 py-0.5 rounded-md">
          {job.location}
        </span>
        <span className="bg-blue-50/50 border border-blue-100/50 text-blue-600 font-semibold px-2 py-0.5 rounded-md">
          {job.salary}
        </span>
      </div>

      {/* Middle info */}
      <div className="text-xs text-slate-600 line-clamp-2 mb-3 leading-relaxed">
        {job.description}
      </div>

      {/* Footer info: dates / application status */}
      <div className="flex items-center justify-between pt-2 border-t border-slate-50 text-[10px] text-slate-400">
        <span className="flex items-center gap-1">
          <Calendar className="w-3 w-3 text-slate-400" />
          Posted {job.postedAt}
        </span>
        {appliedInfo ? (
          <span
            id={`applied-badge-${job.id}`}
            className={`px-2 py-0.5 rounded-full font-bold border text-[9px] uppercase tracking-wide flex items-center gap-1 ${getStatusColor(appliedInfo.status)}`}
          >
            <span className="w-1 h-1 rounded-full bg-current"></span>
            {appliedInfo.status}
          </span>
        ) : (
          <span className="text-slate-400">
            Apply by: <strong className="text-slate-500">{job.deadline}</strong>
          </span>
        )}
      </div>
    </motion.div>
  );
}
