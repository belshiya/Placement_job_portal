import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import StatsDashboard from './components/StatsDashboard';
import FiltersSidebar from './components/FiltersSidebar';
import JobCard from './components/JobCard';
import JobDetailView from './components/JobDetailView';
import ApplicationForm from './components/ApplicationForm';
import { jobsData } from './data/jobsData';
import { Job, Application } from './types';
import { Search, SlidersHorizontal, ArrowUpDown, Sparkles, CheckCircle2, Bookmark, FileText, ChevronRight, X, Briefcase } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface FilterState {
  searchQuery: string;
  location: string;
  department: string;
  type: string;
  experience: string;
  sortBy: 'latest' | 'salary' | 'title';
}

const INITIAL_FILTERS: FilterState = {
  searchQuery: '',
  location: '',
  department: '',
  type: '',
  experience: '',
  sortBy: 'latest',
};

export default function App() {
  // Tabs Navigation State
  const [currentTab, setCurrentTab] = useState<'explore' | 'bookmarks' | 'applied'>('explore');

  // Job Listing Data
  const [jobs, setJobs] = useState<Job[]>(jobsData);
  const [selectedJobId, setSelectedJobId] = useState<string>(jobsData[0]?.id || '');

  // Search & Filter State
  const [filters, setFilters] = useState<FilterState>(INITIAL_FILTERS);
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Persistence State
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);

  // Application Modal/Form State
  const [isApplying, setIsApplying] = useState(false);
  const [applicationSuccess, setApplicationSuccess] = useState<string | null>(null);

  // Mobile specific: Detail panel active
  const [showMobileDetails, setShowMobileDetails] = useState(false);

  // Load Bookmarks and Applications from Local Storage
  useEffect(() => {
    const savedBookmarks = localStorage.getItem('placement_bookmarks');
    if (savedBookmarks) {
      setBookmarks(JSON.parse(savedBookmarks));
    }

    const savedApplications = localStorage.getItem('placement_applications');
    if (savedApplications) {
      setApplications(JSON.parse(savedApplications));
    }
  }, []);

  // Save Bookmarks to Local Storage
  const handleBookmarkToggle = (jobId: string) => {
    setBookmarks(prev => {
      const updated = prev.includes(jobId)
        ? prev.filter(id => id !== jobId)
        : [...prev, jobId];
      localStorage.setItem('placement_bookmarks', JSON.stringify(updated));
      return updated;
    });
  };

  // Select first job when tab changes or search decreases
  const handleSelectedJobReset = (filteredList: Job[]) => {
    if (filteredList.length > 0) {
      // If previous selected is still in the list, keep it
      const stillAvailable = filteredList.some(j => j.id === selectedJobId);
      if (!stillAvailable) {
        setSelectedJobId(filteredList[0].id);
      }
    }
  };

  // Clear all filters
  const handleClearFilters = () => {
    setFilters(INITIAL_FILTERS);
  };

  // Get dynamic unique configuration collections for selector lists
  const availableLocations = Array.from(new Set(jobsData.map(j => j.location)));
  const availableDepartments = Array.from(new Set(jobsData.map(j => j.department)));
  const availableTypes = Array.from(new Set(jobsData.map(j => j.type)));

  // Filter & Search Logic
  const filteredJobs = jobsData.filter(job => {
    // 1. Tab filtration
    if (currentTab === 'bookmarks') {
      if (!bookmarks.includes(job.id)) return false;
    } else if (currentTab === 'applied') {
      const isApplied = applications.some(a => a.jobId === job.id);
      if (!isApplied) return false;
    }

    // 2. Text Search Match
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      const matchTitle = job.title.toLowerCase().includes(query);
      const matchCompany = job.company.toLowerCase().includes(query);
      const matchDesc = job.description.toLowerCase().includes(query);
      const matchTags = job.tags.some(t => t.toLowerCase().includes(query));
      if (!matchTitle && !matchCompany && !matchDesc && !matchTags) return false;
    }

    // 3. Location Select Match
    if (filters.location && job.location !== filters.location) {
      return false;
    }

    // 4. Department Select Match
    if (filters.department && job.department !== filters.department) {
      return false;
    }

    // 5. Work Type Select Match
    if (filters.type && job.type !== filters.type) {
      return false;
    }

    // 6. Experience Match (Fresher or custom indices)
    if (filters.experience) {
      if (filters.experience === 'fresher') {
        const isFresher = job.experience.toLowerCase().includes('fresher');
        if (!isFresher) return false;
      } else if (filters.experience === 'entry') {
        const isEntry = job.experience.toLowerCase().includes('fresher') || job.experience.toLowerCase().includes('1 year');
        if (!isEntry) return false;
      } else if (filters.experience === 'postgrade') {
        const isPostGrade = job.experience.toLowerCase().includes('post-graduate') || job.experience.toLowerCase().includes('special');
        if (!isPostGrade) return false;
      }
    }

    return true;
  });

  // Sorting Logic
  const sortedJobs = [...filteredJobs].sort((a, b) => {
    if (filters.sortBy === 'latest') {
      return b.rawDate.getTime() - a.rawDate.getTime();
    }
    if (filters.sortBy === 'salary') {
      // Rough parse of salary package (e.g. "12 - 16 LPA" -> 16, "18 - 22 LPA" -> 22)
      const parseSalaryMax = (salaryStr: string) => {
        const numbers = salaryStr.match(/\d+(\.\d+)?/g);
        if (numbers && numbers.length > 0) {
          // If range, return max; else return first number
          const maxNum = parseFloat(numbers[numbers.length - 1]);
          // Check if monthly (e.g. "45k - 60k/month") - scale down slightly or just return 0.6 to representing Lakhs equivalent
          if (salaryStr.includes('month')) {
            return maxNum * 0.12; 
          }
          return maxNum;
        }
        return 0;
      };
      return parseSalaryMax(b.salary) - parseSalaryMax(a.salary);
    }
    if (filters.sortBy === 'title') {
      return a.title.localeCompare(b.title);
    }
    return 0;
  });

  // Sync selected job to respect filtered bounds
  useEffect(() => {
    handleSelectedJobReset(sortedJobs);
  }, [filters, currentTab, bookmarks, applications]);

  // Selected job entity
  const selectedJob = jobsData.find(j => j.id === selectedJobId);

  // Application Handling
  const handleApplicationSubmit = (appDetails: Omit<Application, 'id' | 'appliedAt' | 'status'>) => {
    const submissionDate = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });

    const newApplication: Application = {
      ...appDetails,
      id: `app-${Math.random().toString(36).substr(2, 9)}`,
      appliedAt: submissionDate,
      status: 'Applied',
    };

    const updated = [...applications, newApplication];
    setApplications(updated);
    localStorage.setItem('placement_applications', JSON.stringify(updated));

    setIsApplying(false);
    
    // Trigger Success Toast
    setApplicationSuccess(selectedJob?.title || 'the Selected Opportunity');
    setTimeout(() => {
      setApplicationSuccess(null);
    }, 5000);
  };

  const currentProductBookmarksCount = bookmarks.length;
  const currentProductApplicationsCount = applications.length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans" id="placement-portal-root">
      
      {/* Navigation Header */}
      <Header
        currentTab={currentTab}
        onTabChange={(tab) => {
          setCurrentTab(tab);
          // Auto select first entry in new filter layout
          const updatedSubset = jobsData.filter(job => {
            if (tab === 'bookmarks') return bookmarks.includes(job.id);
            if (tab === 'applied') return applications.some(a => a.jobId === job.id);
            return true;
          });
          if (updatedSubset.length > 0) {
            setSelectedJobId(updatedSubset[0].id);
          }
        }}
        bookmarksCount={currentProductBookmarksCount}
        appliedCount={currentProductApplicationsCount}
      />

      <div className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-5 md:py-6 flex flex-col">
        
        {/* Placement Metrics Statistics Section */}
        <StatsDashboard />

        {/* Global Dashboard Notifications/Toast alerts */}
        <AnimatePresence>
          {applicationSuccess && (
            <motion.div
              id="success-alert-toast"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 mb-6 flex items-start gap-3 shadow-md relative"
            >
              <div className="p-1 bg-emerald-500 rounded-lg text-white">
                <CheckCircle2 className="w-5 h-5 animate-bounce" />
              </div>
              <div className="flex-1">
                <h4 className="text-xs font-extrabold text-emerald-800">Application Submitted Successfully!</h4>
                <p className="text-[11px] text-emerald-600 font-medium">
                  Your university profile details, academic records, and resume have been shared with the recruiter for <strong>{applicationSuccess}</strong>.
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md uppercase tracking-wider">
                    STAMP: SUBMITTED
                  </span>
                  <span className="text-[9px] text-emerald-500 font-bold">Track progress in 'My Applications' tab</span>
                </div>
              </div>
              <button
                id="close-toast-alert-btn"
                onClick={() => setApplicationSuccess(null)}
                className="text-emerald-400 hover:text-emerald-600 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Dynamic Dual/Tri-Column Panel Stack */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 items-stretch">
          
          {/* Static Left Filter Sidebar - 3 Columns on desktop / hidden on mobile modal */}
          <div className="hidden lg:block lg:col-span-3">
            <FiltersSidebar
              filters={filters}
              setFilters={setFilters}
              availableLocations={availableLocations}
              availableDepartments={availableDepartments}
              availableTypes={availableTypes}
              onClear={handleClearFilters}
              resultsCount={sortedJobs.length}
            />
          </div>

          {/* Core Center Listings Deck - 5 Columns on desktop, occupy rest elsewhere */}
          <div className="col-span-1 lg:col-span-5 flex flex-col space-y-4">
            
            {/* Search, Sort & Config Row */}
            <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-xs space-y-3">
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-1 focus-within:border-blue-500 focus-within:bg-white focus-within:ring-1 focus-within:ring-blue-500/10 transition-all">
                <Search className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  id="primary-search-input"
                  type="text"
                  value={filters.searchQuery}
                  onChange={(e) => setFilters(prev => ({ ...prev, searchQuery: e.target.value }))}
                  placeholder="Search role, skills, keywords, company..."
                  className="w-full bg-transparent text-slate-700 placeholder-slate-400 text-xs py-2 outline-hidden font-medium"
                />
                {filters.searchQuery && (
                  <button
                    id="clear-search-btn"
                    onClick={() => setFilters(prev => ({ ...prev, searchQuery: '' }))}
                    className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Sorting and Mobile Filter Toggle Button */}
              <div className="flex items-center justify-between gap-2 border-t border-slate-50 pt-3">
                <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold">
                  <ArrowUpDown className="w-3.5 h-3.5" />
                  Sort:
                  <select
                    id="sort-select-input"
                    value={filters.sortBy}
                    onChange={(e) => setFilters(prev => ({ ...prev, sortBy: e.target.value as any }))}
                    className="bg-transparent text-blue-600 font-bold border-none py-0.5 px-1 rounded-sm focus:ring-1 focus:ring-blue-500/10 cursor-pointer outline-hidden"
                  >
                    <option value="latest">Newest First</option>
                    <option value="salary">Highest Package</option>
                    <option value="title">Alphabetical</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    id="mobile-filters-trigger-btn"
                    onClick={() => setShowMobileFilters(true)}
                    className="lg:hidden flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 py-1.5 px-3 rounded-lg text-[11px] font-bold transition-all cursor-pointer"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    Filters
                  </button>
                  <span className="text-[11px] text-slate-400 font-medium">
                    Found <strong>{sortedJobs.length}</strong> items
                  </span>
                </div>
              </div>
            </div>

            {/* List Deck Dynamic Scroll Pane */}
            <div className="flex-1 overflow-y-auto max-h-[70vh] lg:max-h-[85vh] pr-1 space-y-1.5" id="job-cards-scroll-container">
              {sortedJobs.length > 0 ? (
                sortedJobs.map((job) => {
                  const isBookmarked = bookmarks.includes(job.id);
                  const isSelected = selectedJobId === job.id;
                  const appliedInfo = applications.find(a => a.jobId === job.id);

                  return (
                    <JobCard
                      key={job.id}
                      job={job}
                      isSelected={isSelected}
                      isBookmarked={isBookmarked}
                      appliedInfo={appliedInfo}
                      onSelect={() => {
                        setSelectedJobId(job.id);
                        // Open overlay on mobile
                        setShowMobileDetails(true);
                      }}
                      onBookmarkToggle={(e) => {
                        e.stopPropagation();
                        handleBookmarkToggle(job.id);
                      }}
                    />
                  );
                })
              ) : (
                <div id="empty-results-container" className="bg-white rounded-xl border border-slate-100 p-8 text-center flex flex-col items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 mb-3">
                    <SlidersHorizontal className="w-5 h-5 text-slate-400" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-700 mb-1">No Matches Found</h3>
                  <p className="text-xs text-slate-400 max-w-xs mb-4">
                    We couldn't locate openings matching your key criteria. Try clearing some selective filters layout tags.
                  </p>
                  <button
                    id="panel-reset-filters-btn"
                    onClick={handleClearFilters}
                    className="bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold py-2 px-4 rounded-lg transition-colors cursor-pointer"
                  >
                    Reset Filter Fields
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Comprehensive Right Detail Panel - 4 Columns on desktop */}
          <div className="hidden lg:block lg:col-span-4 h-[75vh] lg:h-[95vh] sticky top-24">
            <JobDetailView
              job={selectedJob}
              isBookmarked={selectedJob ? bookmarks.includes(selectedJob.id) : false}
              onBookmarkToggle={() => selectedJob && handleBookmarkToggle(selectedJob.id)}
              isApplied={selectedJob ? applications.some(a => a.jobId === selectedJob.id) : false}
              appliedInfo={selectedJob ? applications.find(a => a.jobId === selectedJob.id) : undefined}
              onApplyClick={() => setIsApplying(true)}
            />
          </div>

        </div>
      </div>

      {/* Responsive Overlay Mobile Filters Panel Modal */}
      <AnimatePresence>
        {showMobileFilters && (
          <div id="mobile-filter-modal-overlay" className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-end justify-end z-50 lg:hidden">
            <motion.div
              id="mobile-filter-content-card"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-white w-full max-w-sm h-full flex flex-col shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between p-4 bg-slate-50 border-b border-indigo-50/50">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">Dynamic Filter Deck</h3>
                <button
                  id="close-mobile-filter-btn"
                  onClick={() => setShowMobileFilters(false)}
                  className="p-1 px-1.5 rounded-md hover:bg-slate-200 text-slate-500 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                <FiltersSidebar
                  filters={filters}
                  setFilters={setFilters}
                  availableLocations={availableLocations}
                  availableDepartments={availableDepartments}
                  availableTypes={availableTypes}
                  onClear={handleClearFilters}
                  resultsCount={sortedJobs.length}
                />
              </div>

              <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-2">
                <button
                  id="apply-mobile-filter-btn"
                  onClick={() => setShowMobileFilters(false)}
                  className="w-full text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 py-3 rounded-lg transition-colors cursor-pointer text-center"
                >
                  View {sortedJobs.length} results
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Modal Overlay for Job Detail View */}
      <AnimatePresence>
        {showMobileDetails && selectedJob && (
          <div id="mobile-job-details-modal-overlay" className="lg:hidden fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-end justify-center p-0 z-40">
            <motion.div
              id="mobile-details-content-panel"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 220 }}
              className="bg-white w-full max-w-xl h-[85vh] rounded-t-2xl flex flex-col shadow-2xl relative overflow-hidden"
            >
              {/* Floating Close Header button */}
              <div className="absolute left-4 top-4 z-50">
                <button
                  id="close-mobile-details-modal-btn"
                  onClick={() => setShowMobileDetails(false)}
                  className="p-2 rounded-full bg-slate-800/80 text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto">
                <JobDetailView
                  job={selectedJob}
                  isBookmarked={bookmarks.includes(selectedJob.id)}
                  onBookmarkToggle={() => handleBookmarkToggle(selectedJob.id)}
                  isApplied={applications.some(a => a.jobId === selectedJob.id)}
                  appliedInfo={applications.find(a => a.jobId === selectedJob.id)}
                  onApplyClick={() => {
                    setShowMobileDetails(false);
                    setIsApplying(true);
                  }}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Dynamic Absolute Application Intake Form Popup Modal */}
      <AnimatePresence>
        {isApplying && selectedJob && (
          <ApplicationForm
            job={selectedJob}
            onClose={() => setIsApplying(false)}
            onSubmit={handleApplicationSubmit}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
